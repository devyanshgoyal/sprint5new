package com.cg.ibs.loanmgmt.bean;

public enum TransactionType {
		CREDIT, DEBIT;
}

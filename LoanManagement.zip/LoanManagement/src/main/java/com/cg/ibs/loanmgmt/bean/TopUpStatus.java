package com.cg.ibs.loanmgmt.bean;

public enum TopUpStatus {
	PENDING, APPROVED, DENIED;
}

package com.cg.ibs.loanmgmt.ui;

public enum AdminOptions {
	VERIFY_LOAN,VERIFY_PRECLOSURE,LOG_OUT
}
